package gla.joose.birdsim.Interfaces;

import java.awt.Graphics;
import java.util.HashMap;

import gla.joose.birdsim.pieces.Piece;

public interface PaintMethod {
	public void paint(Piece piece, Graphics g, HashMap<String,Integer> auxParams);
}
