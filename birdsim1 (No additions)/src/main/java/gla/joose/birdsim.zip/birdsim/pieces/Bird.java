package gla.joose.birdsim.pieces;

import gla.joose.birdsim.Interfaces.PaintMethod;
import gla.joose.birdsim.Methods.GreenBird;

/**
 * A Bird piece.
 */
public class Bird extends Piece {
    public Bird() {
    	setPaintMethod(new GreenBird());
    }
}