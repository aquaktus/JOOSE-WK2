package gla.joose.birdsim.Methods;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

import gla.joose.birdsim.pieces.Piece;

public class RedFadingForage {
	public void paint(Graphics g, Piece piece) {
		Rectangle r = piece.getRectangle();
    	int color = Color.HSBtoRGB(1, piece.get, 1);
        g.setColor(new Color(color));
        g.fillOval(r.x, r.y, r.width, r.height);
    }
}
