package gla.joose.birdsim.Interfaces;

import java.util.HashMap;
import gla.joose.birdsim.boards.Board;

public interface flyBehaviour {
	public void fly(Board board, HashMap<String,Integer> auxParams);
}
